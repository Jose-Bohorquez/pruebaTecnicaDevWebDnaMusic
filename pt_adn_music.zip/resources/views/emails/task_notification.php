<!DOCTYPE html>
<html>
<head>
    <title>Notificación de Tarea</title>
</head>
<body>
    <h1>Hola!</h1>
    <p>Se ha creado una nueva tarea: {{ $taskTitle }}</p>
    <p><a href="{{ $taskUrl }}">Ver Tarea</a></p>
    <p>Gracias por usar nuestra aplicación!</p>
</body>
</html>
