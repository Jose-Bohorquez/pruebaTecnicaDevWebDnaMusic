

<?php $__env->startSection('content'); ?>
<div class="container mx-auto p-6">
    <h1 class="text-3xl font-bold mb-4">Editar Tarea</h1>

    <form action="<?php echo e(route('tasks.update', $task->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="mb-4">
            <label for="title" class="block text-gray-700 font-semibold">Título</label>
            <input type="text" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm focus:ring focus:ring-blue-500" name="title" id="title" value="<?php echo e(old('title', $task->title)); ?>" required>
        </div>

        <div class="mb-4">
            <label for="description" class="block text-gray-700 font-semibold">Descripción</label>
            <textarea class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm focus:ring focus:ring-blue-500" name="description" id="description" required><?php echo e(old('description', $task->description)); ?></textarea>
        </div>

        <div class="mb-4">
            <label for="status" class="block text-gray-700 font-semibold">Estado</label>
            <select class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm focus:ring focus:ring-blue-500" name="status" id="status" required>
                <option value="pendiente" <?php echo e($task->status == 'pendiente' ? 'selected' : ''); ?>>Pendiente</option>
                <option value="en progreso" <?php echo e($task->status == 'en progreso' ? 'selected' : ''); ?>>En Progreso</option>
                <option value="completada" <?php echo e($task->status == 'completada' ? 'selected' : ''); ?>>Completada</option>
            </select>
        </div>

        <div class="mb-4">
            <label for="due_date" class="block text-gray-700 font-semibold">Fecha Límite</label>
            <input type="date" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm focus:ring focus:ring-blue-500" name="due_date" id="due_date" value="<?php echo e(old('due_date', $task->due_date)); ?>" required>
        </div>

        <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition">Actualizar</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pt_adn_music\resources\views\tasks\edit.blade.php ENDPATH**/ ?>